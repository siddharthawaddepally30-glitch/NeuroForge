export interface Question {
  id: string;
  category: string;
  text: string;
  description?: string;
  weights: Record<string, number>;
}

export interface AssessmentResponses {
  [questionId: string]: boolean;
}

export interface LearningProfile {
  visualScore: number;
  auditoryScore: number;
  kinestheticScore: number;
  readingWritingScore: number;
  dominantStyle: 'Visual' | 'Auditory' | 'Kinesthetic' | 'Reading/Writing';
  paceScore: number;
  pace: 'Fast-Paced' | 'Moderate' | 'Detailed';
  engagementStyle: 'Active Participant' | 'Reflective Observer' | 'Balanced';
  strengthAreas: string[];
  growthAreas: string[];
  recommendedTechniques: string[];
  studyEnvironment: string;
  optimalStudyTime: string;
  confidenceScore: number;
}

export interface UserGoals {
  primaryGoal: string;
  subjects: string[];
  timeline: string;
  targetGrade?: string;
}

export interface StudyPlan {
  weeklySchedule: {
    day: string;
    sessions: {
      time: string;
      subject: string;
      technique: string;
      duration: number;
    }[];
  }[];
  techniques: {
    name: string;
    description: string;
    suited_for: string;
  }[];
  resources: {
    subject: string;
    type: 'videos' | 'books' | 'interactive' | 'practice';
    examples: string[];
  }[];
  tips: string[];
}
