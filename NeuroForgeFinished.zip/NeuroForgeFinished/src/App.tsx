import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { LearningProvider } from './contexts/LearningContext';
import { Landing } from './components/Landing';
import { Assessment } from './components/Assessment';
import { Results } from './components/Results';
import { Goals } from './components/Goals';
import { StudyPlan } from './components/StudyPlan';

function App() {
  return (
    <Router>
      <LearningProvider>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/assess" element={<Assessment />} />
          <Route path="/results" element={<Results />} />
          <Route path="/goals" element={<Goals />} />
          <Route path="/plan" element={<StudyPlan />} />
        </Routes>
      </LearningProvider>
    </Router>
  );
}

export default App;
