import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Brain, Zap, BarChart3, CheckCircle } from 'lucide-react';

export const Landing: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-white to-primary-100">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Brain className="w-8 h-8 text-primary-600" />
              <span className="text-2xl font-bold text-primary-900">Neuro Forge</span>
            </div>
            <button
              onClick={() => navigate('/assess')}
              className="px-6 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition font-medium"
            >
              Start Assessment
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <section className="pt-20 pb-16 text-center">
          <div className="animate-slideUp">
            <h1 className="text-5xl md:text-6xl font-bold text-primary-900 mb-6">
              Discover Your
              <span className="bg-gradient-to-r from-primary-600 to-accent-500 bg-clip-text text-transparent"> Unique Learning Path</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Every student learns differently. Our intelligent assessment reveals your learning style, optimal pace, and personalized strategies to maximize your academic success.
            </p>
            <button
              onClick={() => navigate('/assess')}
              className="inline-block px-8 py-4 bg-gradient-to-r from-primary-600 to-primary-700 text-white text-lg font-semibold rounded-xl hover:shadow-xl hover:scale-105 transition-all duration-300"
            >
              Explore Your Learning Style
            </button>
          </div>
        </section>

        <section className="py-16">
          <h2 className="text-3xl font-bold text-center text-primary-900 mb-12">
            Why Neuro Forge Works
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Feature
              icon={<Brain className="w-8 h-8" />}
              title="Personalized Insights"
              description="Get detailed insights about your learning style, including visual, auditory, kinesthetic, and reading/writing preferences."
            />
            <Feature
              icon={<Zap className="w-8 h-8" />}
              title="Optimized Strategies"
              description="Receive customized study techniques and strategies specifically designed for how you learn best."
            />
            <Feature
              icon={<BarChart3 className="w-8 h-8" />}
              title="Smart Study Plans"
              description="Get AI-generated weekly study schedules and resource recommendations tailored to your unique profile."
            />
          </div>
        </section>

        <section className="py-16 bg-white rounded-2xl px-8">
          <h2 className="text-3xl font-bold text-primary-900 mb-12">
            What You'll Discover
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            <DiscoveryItem title="Your Learning Style" description="Visual, Auditory, Kinesthetic, or Reading/Writing" />
            <DiscoveryItem title="Optimal Learning Pace" description="Fast-paced, Moderate, or Detailed approach" />
            <DiscoveryItem title="Engagement Style" description="Active Participant, Reflective Observer, or Balanced" />
            <DiscoveryItem title="Perfect Study Environment" description="Quiet space, background music, or adaptable" />
            <DiscoveryItem title="Best Study Techniques" description="Tailored methods matching your learning style" />
            <DiscoveryItem title="Personalized Schedule" description="Weekly study plan optimized for your success" />
          </div>
        </section>

        <section className="py-16 bg-gradient-to-r from-primary-600 to-primary-700 rounded-2xl text-white text-center my-16">
          <h2 className="text-3xl font-bold mb-4">Ready to Transform Your Learning?</h2>
          <p className="text-primary-100 mb-8 text-lg">
            Spend just 5-10 minutes on our quick assessment and unlock your personalized learning blueprint.
          </p>
          <button
            onClick={() => navigate('/assess')}
            className="px-8 py-4 bg-white text-primary-600 font-bold rounded-xl hover:bg-primary-50 transition text-lg"
          >
            Start Your Assessment Now
          </button>
        </section>

        <section className="py-16">
          <h2 className="text-3xl font-bold text-center text-primary-900 mb-12">
            How It Works
          </h2>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { step: '1', title: 'Answer Questions', desc: 'Complete a quick questionnaire about your learning preferences' },
              { step: '2', title: 'Get Analyzed', desc: 'Our algorithm analyzes your responses to identify patterns' },
              { step: '3', title: 'View Profile', desc: 'See your detailed learning profile with insights' },
              { step: '4', title: 'Get Plan', desc: 'Receive your personalized study plan and strategies' },
            ].map((item) => (
              <div key={item.step} className="text-center">
                <div className="w-16 h-16 mx-auto bg-primary-600 text-white rounded-full flex items-center justify-center text-2xl font-bold mb-4">
                  {item.step}
                </div>
                <h3 className="font-bold text-lg text-primary-900 mb-2">{item.title}</h3>
                <p className="text-gray-600 text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="py-16 text-center">
          <h2 className="text-2xl font-bold text-primary-900 mb-12">Questions About Neuro Forge?</h2>
          <div className="space-y-6 max-w-2xl mx-auto">
            <FAQ question="How long does the assessment take?" answer="The assessment typically takes 5-10 minutes. You can complete it at your own pace and save your progress." />
            <FAQ question="Is my data private?" answer="Yes, all your data is stored securely on your device using local storage. We never collect or share your information." />
            <FAQ question="Can I retake the assessment?" answer="Absolutely! You can retake the assessment anytime to see how your learning preferences evolve." />
            <FAQ question="How is my study plan created?" answer="Our algorithm analyzes your learning style, pace, and preferences to generate a customized weekly study schedule with tailored techniques." />
          </div>
        </section>
      </main>

      <footer className="bg-primary-900 text-white py-8 mt-16">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p>&copy; 2024 Neuro Forge. Designed for personalized learning success.</p>
        </div>
      </footer>
    </div>
  );
};

const Feature: React.FC<{ icon: React.ReactNode; title: string; description: string }> = ({
  icon,
  title,
  description,
}) => (
  <div className="p-8 bg-white rounded-xl shadow-sm hover:shadow-lg transition">
    <div className="text-primary-600 mb-4">{icon}</div>
    <h3 className="text-xl font-bold text-primary-900 mb-3">{title}</h3>
    <p className="text-gray-600">{description}</p>
  </div>
);

const DiscoveryItem: React.FC<{ title: string; description: string }> = ({ title, description }) => (
  <div className="flex items-start gap-4">
    <CheckCircle className="w-6 h-6 text-success-500 flex-shrink-0 mt-1" />
    <div>
      <h3 className="font-bold text-primary-900 mb-1">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  </div>
);

const FAQ: React.FC<{ question: string; answer: string }> = ({ question, answer }) => (
  <div className="text-left p-6 bg-primary-50 rounded-lg">
    <h3 className="font-bold text-primary-900 mb-2">{question}</h3>
    <p className="text-gray-700">{answer}</p>
  </div>
);
