import React, { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Clock, BookMarked, Lightbulb, Download, ChevronDown } from 'lucide-react';
import { useLearning } from '../contexts/LearningContext';
import { generateStudyPlan } from '../utils/studyPlans';

export const StudyPlan: React.FC = () => {
  const navigate = useNavigate();
  const { learningProfile, userGoals } = useLearning();
  const [expandedDay, setExpandedDay] = React.useState<string | null>('Monday');

  if (!learningProfile || !userGoals) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 mb-4">Study plan data not found.</p>
          <button
            onClick={() => navigate('/assess')}
            className="px-6 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700"
          >
            Start Over
          </button>
        </div>
      </div>
    );
  }

  const plan = useMemo(() => generateStudyPlan(learningProfile), [learningProfile]);

  const handleDownload = () => {
    const content = `
PERSONALIZED STUDY PLAN
=======================

Goal: ${userGoals.primaryGoal}
Subjects: ${userGoals.subjects.join(', ')}
Timeline: ${userGoals.timeline}

Learning Style: ${learningProfile.dominantStyle}
Pace: ${learningProfile.pace}
Engagement: ${learningProfile.engagementStyle}

WEEKLY SCHEDULE:
${plan.weeklySchedule
  .map(
    day => `
${day.day}:
${day.sessions
  .map(
    session => `  ${session.time} - ${session.subject} (${session.duration} min)
    Technique: ${session.technique}`
  )
  .join('\n')}
`
  )
  .join('\n')}

RECOMMENDED TECHNIQUES:
${plan.techniques.map(t => `- ${t.name}: ${t.description}`).join('\n')}

STUDY TIPS:
${plan.tips.map(t => `- ${t}`).join('\n')}
    `;

    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(content));
    element.setAttribute('download', 'study-plan.txt');
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-white to-primary-100">
      <nav className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <h1 className="text-2xl font-bold text-primary-900">Your Personalized Study Plan</h1>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-lg p-8 mb-8 animate-slideUp">
              <div className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">Your Goals</h2>
                <p className="text-gray-700 mb-4 leading-relaxed">{userGoals.primaryGoal}</p>
                <div className="flex flex-wrap gap-2">
                  {userGoals.subjects.map((subject, idx) => (
                    <span
                      key={idx}
                      className="px-4 py-2 bg-primary-100 text-primary-700 rounded-full text-sm font-medium"
                    >
                      {subject}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
              <h2 className="text-2xl font-bold text-primary-900 mb-6">Weekly Schedule</h2>
              <div className="space-y-3">
                {plan.weeklySchedule.map(dayPlan => (
                  <div key={dayPlan.day} className="border-2 border-gray-200 rounded-lg overflow-hidden">
                    <button
                      onClick={() =>
                        setExpandedDay(expandedDay === dayPlan.day ? null : dayPlan.day)
                      }
                      className="w-full p-4 flex items-center justify-between hover:bg-gray-50 transition font-bold text-primary-900"
                    >
                      <span>{dayPlan.day}</span>
                      <ChevronDown
                        className={`w-5 h-5 transition-transform ${
                          expandedDay === dayPlan.day ? 'rotate-180' : ''
                        }`}
                      />
                    </button>
                    {expandedDay === dayPlan.day && (
                      <div className="border-t border-gray-200 p-4 bg-gray-50 space-y-3">
                        {dayPlan.sessions.map((session, idx) => (
                          <div key={idx} className="p-4 bg-white rounded-lg border border-gray-200">
                            <div className="flex items-start gap-4">
                              <div className="flex-1">
                                <p className="font-bold text-primary-900">{session.subject}</p>
                                <p className="text-sm text-gray-600 mt-1">{session.technique}</p>
                              </div>
                              <div className="text-right">
                                <p className="font-medium text-primary-600">{session.time}</p>
                                <p className="text-sm text-gray-600 flex items-center gap-1 justify-end mt-1">
                                  <Clock className="w-4 h-4" />
                                  {session.duration}m
                                </p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
              <h2 className="text-2xl font-bold text-primary-900 mb-6 flex items-center gap-2">
                <BookMarked className="w-6 h-6" />
                Recommended Techniques
              </h2>
              <div className="grid md:grid-cols-2 gap-4">
                {plan.techniques.map((technique, idx) => (
                  <div key={idx} className="p-4 bg-primary-50 rounded-lg border border-primary-200">
                    <h4 className="font-bold text-primary-900 mb-2">{technique.name}</h4>
                    <p className="text-sm text-gray-700 mb-3">{technique.description}</p>
                    <p className="text-xs text-primary-600 font-medium">Best for: {technique.suited_for}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h2 className="text-2xl font-bold text-primary-900 mb-6 flex items-center gap-2">
                <Lightbulb className="w-6 h-6" />
                Study Tips for Success
              </h2>
              <ul className="space-y-3">
                {plan.tips.map((tip, idx) => (
                  <li key={idx} className="flex gap-3">
                    <div className="w-6 h-6 rounded-full bg-primary-600 text-white flex items-center justify-center text-sm font-bold flex-shrink-0">
                      ✓
                    </div>
                    <p className="text-gray-700 pt-0.5">{tip}</p>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-lg p-8 sticky top-20">
              <h3 className="text-lg font-bold text-primary-900 mb-6">Plan Summary</h3>

              <div className="space-y-6 mb-8">
                <div className="p-4 bg-primary-50 rounded-lg">
                  <p className="text-xs font-semibold text-primary-600 uppercase tracking-wide mb-1">
                    Learning Style
                  </p>
                  <p className="text-lg font-bold text-primary-900">{learningProfile.dominantStyle}</p>
                </div>

                <div className="p-4 bg-accent-50 rounded-lg">
                  <p className="text-xs font-semibold text-primary-600 uppercase tracking-wide mb-1">
                    Learning Pace
                  </p>
                  <p className="text-lg font-bold text-accent-600">{learningProfile.pace}</p>
                </div>

                <div className="p-4 bg-success-50 rounded-lg">
                  <p className="text-xs font-semibold text-primary-600 uppercase tracking-wide mb-1">
                    Timeline
                  </p>
                  <p className="text-lg font-bold text-success-600">{userGoals.timeline}</p>
                </div>
              </div>

              <button
                onClick={handleDownload}
                className="w-full mb-3 px-4 py-3 bg-gradient-to-r from-primary-600 to-primary-700 text-white rounded-lg font-bold hover:shadow-lg transition flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                Download Plan
              </button>

              <button
                onClick={() => {
                  if (window.confirm('Create a new study plan? Your current profile will be saved.')) {
                    navigate('/goals');
                  }
                }}
                className="w-full px-4 py-3 border-2 border-primary-200 text-primary-600 rounded-lg font-bold hover:bg-primary-50 transition"
              >
                Adjust Goals
              </button>

              <button
                onClick={() => navigate('/results')}
                className="w-full mt-3 px-4 py-3 text-primary-600 hover:bg-primary-50 rounded-lg font-medium transition"
              >
                View Profile
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
