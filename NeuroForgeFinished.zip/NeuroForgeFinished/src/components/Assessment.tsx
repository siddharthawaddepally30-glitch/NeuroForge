import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronRight, ChevronLeft, Check } from 'lucide-react';
import { useLearning } from '../contexts/LearningContext';
import { assessmentQuestions } from '../data/questions';

export const Assessment: React.FC = () => {
  const navigate = useNavigate();
  const { currentQuestionIndex, setCurrentQuestionIndex, setResponse, responses, completeAssessment } = useLearning();
  const [isLoading, setIsLoading] = useState(false);

  const question = assessmentQuestions[currentQuestionIndex];
  const totalQuestions = assessmentQuestions.length;
  const progress = ((currentQuestionIndex + 1) / totalQuestions) * 100;

  const isAnswered = responses[question.id] !== undefined;
  const currentAnswer = responses[question.id];

  const handleNext = () => {
    if (currentQuestionIndex < totalQuestions - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const handleComplete = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500));
    completeAssessment();
    setIsLoading(false);
    navigate('/results');
  };

  const handleYes = () => setResponse(question.id, true);
  const handleNo = () => setResponse(question.id, false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-white to-primary-100">
      <nav className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-primary-900">Learning Style Assessment</h1>
            <span className="text-sm font-medium text-gray-600">
              Question {currentQuestionIndex + 1} of {totalQuestions}
            </span>
          </div>
        </div>
      </nav>

      <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700">Progress</span>
            <span className="text-sm font-medium text-primary-600">{Math.round(progress)}%</span>
          </div>
          <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-primary-500 to-primary-600 transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12 animate-slideUp">
          <div className="mb-8">
            <p className="text-sm font-semibold text-primary-600 uppercase tracking-wide mb-2">
              {question.category}
            </p>
            <h2 className="text-3xl md:text-4xl font-bold text-primary-900 mb-4">
              {question.text}
            </h2>
            {question.description && (
              <p className="text-lg text-gray-600 leading-relaxed">
                {question.description}
              </p>
            )}
          </div>

          <div className="mb-12">
            <p className="text-sm font-medium text-gray-700 mb-6">Select your answer:</p>
            <div className="grid md:grid-cols-2 gap-4">
              <button
                onClick={handleYes}
                className={`p-6 rounded-xl font-bold text-lg transition-all duration-300 flex items-center justify-center gap-3 ${
                  currentAnswer === true
                    ? 'bg-success-500 text-white shadow-lg scale-105'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <Check className="w-6 h-6" />
                Yes
              </button>
              <button
                onClick={handleNo}
                className={`p-6 rounded-xl font-bold text-lg transition-all duration-300 flex items-center justify-center gap-3 ${
                  currentAnswer === false
                    ? 'bg-accent-500 text-white shadow-lg scale-105'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <Check className="w-6 h-6" />
                No
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between gap-4">
            <button
              onClick={handlePrevious}
              disabled={currentQuestionIndex === 0}
              className="flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-100"
            >
              <ChevronLeft className="w-5 h-5" />
              Previous
            </button>

            {currentQuestionIndex === totalQuestions - 1 ? (
              <button
                onClick={handleComplete}
                disabled={!isAnswered || isLoading}
                className="flex items-center gap-2 px-8 py-3 bg-gradient-to-r from-primary-600 to-primary-700 text-white rounded-lg font-bold hover:shadow-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? 'Analyzing...' : 'Complete Assessment'}
              </button>
            ) : (
              <button
                onClick={handleNext}
                disabled={!isAnswered}
                className="flex items-center gap-2 px-8 py-3 bg-gradient-to-r from-primary-600 to-primary-700 text-white rounded-lg font-bold hover:shadow-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Next
                <ChevronRight className="w-5 h-5" />
              </button>
            )}
          </div>

          <div className="mt-8 pt-8 border-t border-gray-200">
            <p className="text-sm text-gray-600 text-center">
              Your answers are automatically saved. You can revisit previous questions anytime.
            </p>
          </div>
        </div>

        <div className="mt-8 text-center">
          <button
            onClick={() => {
              if (window.confirm('Are you sure you want to exit? Your progress will be saved.')) {
                navigate('/');
              }
            }}
            className="text-gray-600 hover:text-primary-600 font-medium transition"
          >
            Exit Assessment
          </button>
        </div>
      </main>
    </div>
  );
};
