import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Target, BookOpen, Calendar } from 'lucide-react';
import { useLearning } from '../contexts/LearningContext';

const SUBJECTS = [
  'Mathematics', 'Science', 'History', 'Literature', 'Languages',
  'Physics', 'Chemistry', 'Biology', 'Geography', 'Economics',
  'Computer Science', 'Arts', 'Music', 'Sports', 'Philosophy'
];

export const Goals: React.FC = () => {
  const navigate = useNavigate();
  const { setUserGoals, userGoals } = useLearning();
  const [goal, setGoal] = useState(userGoals?.primaryGoal || '');
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>(userGoals?.subjects || []);
  const [timeline, setTimeline] = useState(userGoals?.timeline || '');

  const toggleSubject = (subject: string) => {
    setSelectedSubjects(prev =>
      prev.includes(subject)
        ? prev.filter(s => s !== subject)
        : [...prev, subject]
    );
  };

  const handleNext = () => {
    if (!goal.trim() || selectedSubjects.length === 0 || !timeline) {
      alert('Please fill in all fields');
      return;
    }
    setUserGoals({
      primaryGoal: goal,
      subjects: selectedSubjects,
      timeline,
    });
    navigate('/plan');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-white to-primary-100">
      <nav className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <h1 className="text-2xl font-bold text-primary-900">Your Learning Goals</h1>
        </div>
      </nav>

      <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-2xl shadow-lg p-8 animate-slideUp">
          <p className="text-gray-600 mb-8">
            Let's personalize your study plan based on your goals and interests. This helps us create a study schedule that matters to you.
          </p>

          <div className="space-y-8">
            <div>
              <label className="flex items-center gap-2 text-lg font-bold text-primary-900 mb-4">
                <Target className="w-5 h-5 text-primary-600" />
                What's your primary learning goal?
              </label>
              <textarea
                value={goal}
                onChange={(e) => setGoal(e.target.value)}
                placeholder="e.g., Improve my grades, prepare for exams, learn a new skill, master a subject..."
                className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-primary-500 focus:outline-none resize-none"
                rows={4}
              />
            </div>

            <div>
              <label className="flex items-center gap-2 text-lg font-bold text-primary-900 mb-4">
                <BookOpen className="w-5 h-5 text-primary-600" />
                Select your subjects of interest:
              </label>
              <div className="grid md:grid-cols-2 gap-3">
                {SUBJECTS.map(subject => (
                  <button
                    key={subject}
                    onClick={() => toggleSubject(subject)}
                    className={`p-3 rounded-lg font-medium transition ${
                      selectedSubjects.includes(subject)
                        ? 'bg-primary-600 text-white shadow-md'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {subject}
                  </button>
                ))}
              </div>
              {selectedSubjects.length > 0 && (
                <p className="text-sm text-primary-600 mt-3 font-medium">
                  {selectedSubjects.length} subject{selectedSubjects.length !== 1 ? 's' : ''} selected
                </p>
              )}
            </div>

            <div>
              <label className="flex items-center gap-2 text-lg font-bold text-primary-900 mb-4">
                <Calendar className="w-5 h-5 text-primary-600" />
                What's your timeline?
              </label>
              <select
                value={timeline}
                onChange={(e) => setTimeline(e.target.value)}
                className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-primary-500 focus:outline-none"
              >
                <option value="">Select a timeline...</option>
                <option value="1-month">1 Month</option>
                <option value="3-months">3 Months</option>
                <option value="6-months">6 Months</option>
                <option value="1-year">1 Year</option>
                <option value="ongoing">Ongoing Learning</option>
              </select>
            </div>
          </div>

          <div className="mt-12 flex gap-4">
            <button
              onClick={() => navigate('/results')}
              className="flex-1 px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-lg font-bold hover:bg-gray-50 transition"
            >
              Back
            </button>
            <button
              onClick={handleNext}
              className="flex-1 px-6 py-3 bg-gradient-to-r from-primary-600 to-primary-700 text-white rounded-lg font-bold hover:shadow-lg transition flex items-center justify-center gap-2"
            >
              Generate Study Plan
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};
