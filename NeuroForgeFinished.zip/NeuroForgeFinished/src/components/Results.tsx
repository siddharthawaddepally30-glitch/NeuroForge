import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Download, Share2, TrendingUp, Lightbulb } from 'lucide-react';
import { useLearning } from '../contexts/LearningContext';

const LEARNING_STYLE_ICONS: Record<string, string> = {
  'Visual': '👁️',
  'Auditory': '👂',
  'Kinesthetic': '✋',
  'Reading/Writing': '📝',
};

const LEARNING_STYLE_COLORS: Record<string, string> = {
  'Visual': 'from-blue-500 to-blue-600',
  'Auditory': 'from-green-500 to-green-600',
  'Kinesthetic': 'from-orange-500 to-orange-600',
  'Reading/Writing': 'from-purple-500 to-purple-600',
};

export const Results: React.FC = () => {
  const navigate = useNavigate();
  const { learningProfile } = useLearning();

  if (!learningProfile) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 mb-4">No assessment results found.</p>
          <button
            onClick={() => navigate('/assess')}
            className="px-6 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700"
          >
            Start Assessment
          </button>
        </div>
      </div>
    );
  }

  const scoreData = [
    { label: 'Visual', score: learningProfile.visualScore },
    { label: 'Auditory', score: learningProfile.auditoryScore },
    { label: 'Kinesthetic', score: learningProfile.kinestheticScore },
    { label: 'Reading/Writing', score: learningProfile.readingWritingScore },
  ];

  const handleDownload = () => {
    const profile = learningProfile;
    const content = `
LEARNING STYLE PROFILE REPORT
=============================

PRIMARY LEARNING STYLE: ${profile.dominantStyle}
Confidence Score: ${profile.confidenceScore}%

LEARNING MODALITIES BREAKDOWN:
- Visual: ${profile.visualScore}%
- Auditory: ${profile.auditoryScore}%
- Kinesthetic: ${profile.kinestheticScore}%
- Reading/Writing: ${profile.readingWritingScore}%

LEARNING PACE: ${profile.pace}
ENGAGEMENT STYLE: ${profile.engagementStyle}

STRENGTH AREAS:
${profile.strengthAreas.map(a => `- ${a}`).join('\n')}

AREAS FOR GROWTH:
${profile.growthAreas.map(a => `- ${a}`).join('\n')}

RECOMMENDED STUDY TECHNIQUES:
${profile.recommendedTechniques.map(t => `- ${t}`).join('\n')}

OPTIMAL STUDY ENVIRONMENT: ${profile.studyEnvironment}
RECOMMENDED STUDY TIME: ${profile.optimalStudyTime}
    `;

    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(content));
    element.setAttribute('download', 'learning-profile.txt');
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleShare = () => {
    const text = `I just discovered my learning style! My dominant learning style is ${learningProfile.dominantStyle}. I prefer a ${learningProfile.pace} pace and I'm a ${learningProfile.engagementStyle} learner. Learn your style on Neuro Forge!`;
    if (navigator.share) {
      navigator.share({ title: 'My Learning Profile', text });
    } else {
      navigator.clipboard.writeText(text);
      alert('Profile text copied to clipboard!');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-white to-primary-100">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <h1 className="text-2xl font-bold text-primary-900">Your Learning Profile</h1>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-lg p-8 mb-8 animate-slideUp">
              <div className={`bg-gradient-to-r ${LEARNING_STYLE_COLORS[learningProfile.dominantStyle]} rounded-xl p-8 text-white mb-8`}>
                <p className="text-sm font-semibold uppercase tracking-wide mb-2 opacity-90">Your Dominant Learning Style</p>
                <div className="flex items-center gap-6">
                  <div className="text-6xl">{LEARNING_STYLE_ICONS[learningProfile.dominantStyle]}</div>
                  <div>
                    <h2 className="text-4xl font-bold mb-2">{learningProfile.dominantStyle}</h2>
                    <p className="text-lg opacity-90">Confidence: {learningProfile.confidenceScore}%</p>
                  </div>
                </div>
              </div>

              <div className="mb-8">
                <h3 className="text-xl font-bold text-primary-900 mb-6">Learning Modalities</h3>
                <div className="space-y-4">
                  {scoreData.map(({ label, score }) => (
                    <div key={label}>
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-gray-700">{label}</span>
                        <span className="text-sm font-bold text-primary-600">{score}%</span>
                      </div>
                      <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-primary-400 to-primary-600 transition-all duration-500"
                          style={{ width: `${score}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6 mb-8">
                <div className="p-4 bg-primary-50 rounded-lg">
                  <p className="text-sm font-semibold text-primary-900 mb-1">Learning Pace</p>
                  <p className="text-lg font-bold text-primary-600">{learningProfile.pace}</p>
                </div>
                <div className="p-4 bg-accent-50 rounded-lg">
                  <p className="text-sm font-semibold text-primary-900 mb-1">Engagement Style</p>
                  <p className="text-lg font-bold text-accent-600">{learningProfile.engagementStyle}</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
              <div className="flex items-center gap-3 mb-6">
                <TrendingUp className="w-6 h-6 text-success-500" />
                <h3 className="text-xl font-bold text-primary-900">Strength Areas</h3>
              </div>
              <div className="space-y-3">
                {learningProfile.strengthAreas.map((area, idx) => (
                  <div key={idx} className="flex items-start gap-3 p-3 bg-success-50 rounded-lg">
                    <div className="w-5 h-5 rounded-full bg-success-500 text-white flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">
                      ✓
                    </div>
                    <p className="text-gray-700">{area}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
              <div className="flex items-center gap-3 mb-6">
                <Lightbulb className="w-6 h-6 text-warm-500" />
                <h3 className="text-xl font-bold text-primary-900">Areas for Growth</h3>
              </div>
              <div className="space-y-3">
                {learningProfile.growthAreas.map((area, idx) => (
                  <div key={idx} className="flex items-start gap-3 p-3 bg-warm-50 rounded-lg">
                    <div className="w-5 h-5 rounded-full bg-warm-500 flex-shrink-0 mt-0.5" />
                    <p className="text-gray-700">{area}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h3 className="text-xl font-bold text-primary-900 mb-6">Recommended Study Techniques</h3>
              <div className="grid md:grid-cols-2 gap-4">
                {learningProfile.recommendedTechniques.map((technique, idx) => (
                  <div key={idx} className="p-4 border-2 border-primary-200 rounded-lg hover:border-primary-400 transition">
                    <p className="font-medium text-primary-900">{technique}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-lg p-8 sticky top-4">
              <h3 className="text-lg font-bold text-primary-900 mb-6">Quick Info</h3>

              <div className="space-y-6 mb-8">
                <div>
                  <p className="text-sm text-gray-600 mb-2">Study Environment</p>
                  <p className="font-medium text-primary-900">{learningProfile.studyEnvironment}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-2">Optimal Study Time</p>
                  <p className="font-medium text-primary-900">{learningProfile.optimalStudyTime}</p>
                </div>
              </div>

              <button
                onClick={() => navigate('/goals')}
                className="w-full mb-3 px-6 py-3 bg-gradient-to-r from-primary-600 to-primary-700 text-white rounded-lg font-bold hover:shadow-lg transition flex items-center justify-center gap-2"
              >
                Create Study Plan
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={handleDownload}
                className="w-full mb-3 px-6 py-3 border-2 border-primary-200 text-primary-600 rounded-lg font-bold hover:bg-primary-50 transition flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                Download Report
              </button>

              <button
                onClick={handleShare}
                className="w-full mb-3 px-6 py-3 border-2 border-accent-200 text-accent-600 rounded-lg font-bold hover:bg-accent-50 transition flex items-center justify-center gap-2"
              >
                <Share2 className="w-4 h-4" />
                Share Profile
              </button>

              <button
                onClick={() => {
                  if (window.confirm('Retake the assessment? Your current results will be preserved.')) {
                    navigate('/assess');
                  }
                }}
                className="w-full px-6 py-3 text-primary-600 hover:bg-primary-50 rounded-lg font-medium transition"
              >
                Retake Assessment
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
