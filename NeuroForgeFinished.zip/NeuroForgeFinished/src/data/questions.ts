import { Question } from '../types';

export const assessmentQuestions: Question[] = [
  {
    id: 'q1',
    category: 'Learning Modality',
    text: 'Do you prefer learning through visual materials like diagrams, charts, and videos?',
    description: 'Visual learning involves understanding concepts through images and visual representations.',
    weights: { visual: 3, auditory: 0, kinesthetic: 0, readingWriting: 0 }
  },
  {
    id: 'q2',
    category: 'Learning Modality',
    text: 'Do you learn better when someone explains concepts to you verbally?',
    weights: { visual: 0, auditory: 3, kinesthetic: 0, readingWriting: 0 }
  },
  {
    id: 'q3',
    category: 'Learning Modality',
    text: 'Do you prefer learning by doing and hands-on practice?',
    weights: { visual: 0, auditory: 0, kinesthetic: 3, readingWriting: 0 }
  },
  {
    id: 'q4',
    category: 'Learning Modality',
    text: 'Do you enjoy reading textbooks and learning through written material?',
    weights: { visual: 0, auditory: 0, kinesthetic: 0, readingWriting: 3 }
  },
  {
    id: 'q5',
    category: 'Psychological Traits',
    text: 'Do you get energized by studying in social environments or group settings?',
    description: 'This helps determine your social learning preference.',
    weights: { extroverted: 2, focused: 0, motivation: 1 }
  },
  {
    id: 'q6',
    category: 'Psychological Traits',
    text: 'Do you prefer studying alone without distractions?',
    weights: { extroverted: 0, focused: 2, motivation: 0 }
  },
  {
    id: 'q7',
    category: 'Psychological Traits',
    text: 'Do you respond well to competition and challenges as motivation?',
    weights: { extroverted: 1, focused: 0, motivation: 2 }
  },
  {
    id: 'q8',
    category: 'Learning Speed',
    text: 'Do you prefer a fast-paced learning environment where topics are covered quickly?',
    description: 'Fast-paced learning moves through material rapidly.',
    weights: { fastPace: 3, moderatePace: 0, slowPace: 0 }
  },
  {
    id: 'q9',
    category: 'Learning Speed',
    text: 'Do you prefer detailed explanations and time to deeply understand each concept?',
    weights: { fastPace: 0, moderatePace: 0, slowPace: 3 }
  },
  {
    id: 'q10',
    category: 'Learning Speed',
    text: 'Do you like a balanced approach with adequate time for practice and questions?',
    weights: { fastPace: 0, moderatePace: 2, slowPace: 0 }
  },
  {
    id: 'q11',
    category: 'Classroom Engagement',
    text: 'Do you actively participate and ask questions in classroom settings?',
    description: 'Active engagement helps identify your participation style.',
    weights: { activeParticipant: 3, reflective: 0 }
  },
  {
    id: 'q12',
    category: 'Classroom Engagement',
    text: 'Do you prefer listening and observing before sharing your thoughts?',
    weights: { activeParticipant: 0, reflective: 3 }
  },
  {
    id: 'q13',
    category: 'Classroom Engagement',
    text: 'Do you maintain focus and concentrate easily during lectures?',
    weights: { focus: 2, concentration: 2 }
  },
  {
    id: 'q14',
    category: 'Doubt Clarification',
    text: 'Do you immediately ask for help when you encounter confusion?',
    description: 'This reveals your approach to seeking clarification.',
    weights: { helpSeeking: 3, selfResearch: 0 }
  },
  {
    id: 'q15',
    category: 'Doubt Clarification',
    text: 'Do you prefer researching and finding answers on your own before asking for help?',
    weights: { helpSeeking: 0, selfResearch: 3 }
  },
  {
    id: 'q16',
    category: 'Doubt Clarification',
    text: 'Do you benefit from discussing doubts with peers or in group discussions?',
    weights: { groupDiscussion: 2, collaboration: 2 }
  },
  {
    id: 'q17',
    category: 'Memory & Retention',
    text: 'Do you remember information better when you write it down?',
    description: 'Writing aids memory retention for many learners.',
    weights: { writingMemory: 3, conceptualMemory: 0 }
  },
  {
    id: 'q18',
    category: 'Memory & Retention',
    text: 'Do you grasp concepts better through understanding the "why" rather than memorizing?',
    weights: { writingMemory: 0, conceptualMemory: 3 }
  },
  {
    id: 'q19',
    category: 'Memory & Retention',
    text: 'Do you benefit from repetition and spaced revision to retain information?',
    weights: { spacing: 2, revision: 2 }
  },
  {
    id: 'q20',
    category: 'Study Environment',
    text: 'Do you study best in quiet, distraction-free environments?',
    description: 'Study environment preferences affect your learning quality.',
    weights: { quietEnvironment: 3, adaptable: 0 }
  },
  {
    id: 'q21',
    category: 'Study Environment',
    text: 'Do you focus better with some background noise or music?',
    weights: { quietEnvironment: 0, musicBackground: 3 }
  },
  {
    id: 'q22',
    category: 'Problem-Solving',
    text: 'Do you plan your approach carefully before solving a problem?',
    description: 'This reveals your problem-solving strategy.',
    weights: { analytical: 3, intuitive: 0 }
  },
  {
    id: 'q23',
    category: 'Problem-Solving',
    text: 'Do you prefer trying different approaches until you find a solution?',
    weights: { analytical: 0, intuitive: 3 }
  },
  {
    id: 'q24',
    category: 'Confidence & Motivation',
    text: 'Do you feel confident in your ability to learn new subjects?',
    weights: { confidence: 2, motivation: 1 }
  },
  {
    id: 'q25',
    category: 'Confidence & Motivation',
    text: 'Do you maintain motivation even when facing difficult topics?',
    weights: { confidence: 1, motivation: 3 }
  },
];
