import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { AssessmentResponses, LearningProfile, UserGoals } from '../types';
import { getFromStorage, saveToStorage, LOCAL_STORAGE_KEYS } from '../utils/storage';
import { calculateLearningProfile } from '../utils/scoring';

interface LearningContextType {
  responses: AssessmentResponses;
  learningProfile: LearningProfile | null;
  userGoals: UserGoals | null;
  currentQuestionIndex: number;
  setResponse: (questionId: string, value: boolean) => void;
  setLearningProfile: (profile: LearningProfile) => void;
  setUserGoals: (goals: UserGoals) => void;
  setCurrentQuestionIndex: (index: number) => void;
  resetAssessment: () => void;
  completeAssessment: () => void;
}

const LearningContext = createContext<LearningContextType | undefined>(undefined);

export const LearningProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [responses, setResponses] = useState<AssessmentResponses>(
    getFromStorage(LOCAL_STORAGE_KEYS.ASSESSMENT_RESPONSES, {})
  );
  const [learningProfile, setLearningProfile] = useState<LearningProfile | null>(
    getFromStorage(LOCAL_STORAGE_KEYS.LEARNING_PROFILE, null)
  );
  const [userGoals, setUserGoals] = useState<UserGoals | null>(
    getFromStorage(LOCAL_STORAGE_KEYS.USER_GOALS, null)
  );
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);

  const handleSetResponse = useCallback((questionId: string, value: boolean) => {
    setResponses(prev => {
      const updated = { ...prev, [questionId]: value };
      saveToStorage(LOCAL_STORAGE_KEYS.ASSESSMENT_RESPONSES, updated);
      return updated;
    });
  }, []);

  const handleSetLearningProfile = useCallback((profile: LearningProfile) => {
    setLearningProfile(profile);
    saveToStorage(LOCAL_STORAGE_KEYS.LEARNING_PROFILE, profile);
  }, []);

  const handleSetUserGoals = useCallback((goals: UserGoals) => {
    setUserGoals(goals);
    saveToStorage(LOCAL_STORAGE_KEYS.USER_GOALS, goals);
  }, []);

  const handleResetAssessment = useCallback(() => {
    setResponses({});
    setLearningProfile(null);
    setUserGoals(null);
    setCurrentQuestionIndex(0);
    localStorage.removeItem(LOCAL_STORAGE_KEYS.ASSESSMENT_RESPONSES);
    localStorage.removeItem(LOCAL_STORAGE_KEYS.LEARNING_PROFILE);
    localStorage.removeItem(LOCAL_STORAGE_KEYS.USER_GOALS);
  }, []);

  const handleCompleteAssessment = useCallback(() => {
    const profile = calculateLearningProfile(responses);
    handleSetLearningProfile(profile);
  }, [responses, handleSetLearningProfile]);

  return (
    <LearningContext.Provider
      value={{
        responses,
        learningProfile,
        userGoals,
        currentQuestionIndex,
        setResponse: handleSetResponse,
        setLearningProfile: handleSetLearningProfile,
        setUserGoals: handleSetUserGoals,
        setCurrentQuestionIndex,
        resetAssessment: handleResetAssessment,
        completeAssessment: handleCompleteAssessment,
      }}
    >
      {children}
    </LearningContext.Provider>
  );
};

export const useLearning = () => {
  const context = useContext(LearningContext);
  if (!context) {
    throw new Error('useLearning must be used within LearningProvider');
  }
  return context;
};
