import { AssessmentResponses, LearningProfile } from '../types';
import { assessmentQuestions } from '../data/questions';

export const calculateLearningProfile = (responses: AssessmentResponses): LearningProfile => {
  const scores: Record<string, number> = {
    visual: 0,
    auditory: 0,
    kinesthetic: 0,
    readingWriting: 0,
    fastPace: 0,
    moderatePace: 0,
    slowPace: 0,
    activeParticipant: 0,
    reflective: 0,
  };

  assessmentQuestions.forEach(question => {
    const isYes = responses[question.id];
    if (isYes) {
      Object.entries(question.weights).forEach(([key, value]) => {
        if (key in scores) {
          scores[key] += value;
        }
      });
    }
  });

  const visualScore = (scores.visual / 9) * 100;
  const auditoryScore = (scores.auditory / 9) * 100;
  const kinestheticScore = (scores.kinesthetic / 9) * 100;
  const readingWritingScore = (scores.readingWriting / 9) * 100;

  const modalities = [
    { name: 'Visual' as const, score: visualScore },
    { name: 'Auditory' as const, score: auditoryScore },
    { name: 'Kinesthetic' as const, score: kinestheticScore },
    { name: 'Reading/Writing' as const, score: readingWritingScore },
  ];

  const dominantStyle = modalities.reduce((prev, current) =>
    current.score > prev.score ? current : prev
  ).name;

  const paceScores = {
    'Fast-Paced': scores.fastPace,
    'Moderate': scores.moderatePace,
    'Detailed': scores.slowPace,
  };

  const pace = Object.entries(paceScores).reduce(([prevKey], [currKey]) =>
    paceScores[currKey as keyof typeof paceScores] > paceScores[prevKey as keyof typeof paceScores]
      ? [currKey]
      : [prevKey]
  )[0] as 'Fast-Paced' | 'Moderate' | 'Detailed';

  const activeScore = scores.activeParticipant;
  const reflectiveScore = scores.reflective;

  let engagementStyle: 'Active Participant' | 'Reflective Observer' | 'Balanced';
  if (Math.abs(activeScore - reflectiveScore) <= 1) {
    engagementStyle = 'Balanced';
  } else {
    engagementStyle = activeScore > reflectiveScore ? 'Active Participant' : 'Reflective Observer';
  }

  const strengthAreas = getStrengthAreas(dominantStyle, pace, engagementStyle);
  const growthAreas = getGrowthAreas(dominantStyle, engagementStyle);
  const recommendedTechniques = getRecommendedTechniques(dominantStyle, pace);
  const studyEnvironment = getStudyEnvironment(responses);
  const optimalStudyTime = getOptimalStudyTime(responses);

  const avgScore = (visualScore + auditoryScore + kinestheticScore + readingWritingScore) / 4;
  const confidenceScore = Math.round(Math.max(0, Math.min(100, avgScore + 20)));

  return {
    visualScore: Math.round(visualScore),
    auditoryScore: Math.round(auditoryScore),
    kinestheticScore: Math.round(kinestheticScore),
    readingWritingScore: Math.round(readingWritingScore),
    dominantStyle,
    paceScore: Math.round((Object.values(paceScores).reduce((a, b) => a + b) / 3) * 100 / 6),
    pace,
    engagementStyle,
    strengthAreas,
    growthAreas,
    recommendedTechniques,
    studyEnvironment,
    optimalStudyTime,
    confidenceScore,
  };
};

const getStrengthAreas = (modality: string, pace: string, engagement: string): string[] => {
  const strengths: string[] = [];

  switch (modality) {
    case 'Visual':
      strengths.push('Understanding visual concepts', 'Chart and diagram interpretation');
      break;
    case 'Auditory':
      strengths.push('Listening comprehension', 'Verbal explanation retention');
      break;
    case 'Kinesthetic':
      strengths.push('Practical application', 'Learning by doing');
      break;
    case 'Reading/Writing':
      strengths.push('Reading comprehension', 'Note-taking and writing');
      break;
  }

  if (pace === 'Fast-Paced') {
    strengths.push('Quick concept grasping');
  } else if (pace === 'Detailed') {
    strengths.push('Deep understanding and mastery');
  } else {
    strengths.push('Balanced learning approach');
  }

  if (engagement === 'Active Participant') {
    strengths.push('Interactive learning');
  } else if (engagement === 'Reflective Observer') {
    strengths.push('Thoughtful analysis and reflection');
  }

  return strengths;
};

const getGrowthAreas = (modality: string, engagement: string): string[] => {
  const growth: string[] = [];

  if (modality === 'Visual') {
    growth.push('Developing auditory listening skills');
  } else if (modality === 'Auditory') {
    growth.push('Improving visual interpretation skills');
  } else if (modality === 'Kinesthetic') {
    growth.push('Enhancing reading and writing abilities');
  }

  if (engagement === 'Active Participant') {
    growth.push('Building reflective thinking habits');
  } else if (engagement === 'Reflective Observer') {
    growth.push('Developing confidence in active participation');
  }

  return growth;
};

const getRecommendedTechniques = (modality: string, pace: string): string[] => {
  const techniques: string[] = [];

  switch (modality) {
    case 'Visual':
      techniques.push('Mind mapping', 'Flowcharts', 'Color-coded notes', 'Video tutorials');
      break;
    case 'Auditory':
      techniques.push('Verbal discussion', 'Podcasts', 'Teaching others', 'Audio lectures');
      break;
    case 'Kinesthetic':
      techniques.push('Hands-on projects', 'Practical experiments', 'Physical demonstrations', 'Role-playing');
      break;
    case 'Reading/Writing':
      techniques.push('Note-taking', 'Writing summaries', 'Reading textbooks', 'Journaling');
      break;
  }

  if (pace === 'Fast-Paced') {
    techniques.push('Rapid review sessions');
  } else if (pace === 'Detailed') {
    techniques.push('Deep dive study sessions', 'Extended practice');
  } else {
    techniques.push('Spaced repetition', 'Pomodoro technique');
  }

  return techniques;
};

const getStudyEnvironment = (responses: AssessmentResponses): string => {
  const quietScore = responses['q20'] ? 1 : 0;
  const musicScore = responses['q21'] ? 1 : 0;

  if (quietScore > musicScore) {
    return 'Quiet, distraction-free environment';
  } else if (musicScore > quietScore) {
    return 'Study with background music or ambient sound';
  } else {
    return 'Adaptable study environment';
  }
};

const getOptimalStudyTime = (responses: AssessmentResponses): string => {
  const fastPaceScore = responses['q8'] ? 1 : 0;
  const slowPaceScore = responses['q9'] ? 1 : 0;

  if (fastPaceScore > slowPaceScore) {
    return 'Short, focused study sessions (30-45 minutes)';
  } else if (slowPaceScore > fastPaceScore) {
    return 'Longer, deeper study sessions (60-90 minutes)';
  } else {
    return 'Mixed session lengths (45-60 minutes)';
  }
};
