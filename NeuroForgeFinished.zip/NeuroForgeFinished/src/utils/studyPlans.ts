import { LearningProfile, StudyPlan } from '../types';

export const generateStudyPlan = (profile: LearningProfile): StudyPlan => {
  const techniques = getStudyTechniques(profile);
  const resources = getRecommendedResources(profile);
  const tips = getStudyTips(profile);
  const weeklySchedule = generateWeeklySchedule(profile);

  return {
    weeklySchedule,
    techniques,
    resources,
    tips,
  };
};

const getStudyTechniques = (profile: LearningProfile) => {
  const techniquesMap: Record<string, { name: string; description: string; suited_for: string }[]> = {
    Visual: [
      {
        name: 'Mind Mapping',
        description: 'Create visual maps connecting ideas and concepts with colors and images.',
        suited_for: 'Understanding relationships between concepts'
      },
      {
        name: 'Infographics',
        description: 'Use visual representations to organize information and data.',
        suited_for: 'Comprehending complex information quickly'
      },
      {
        name: 'Video Learning',
        description: 'Watch educational videos and tutorials to visualize concepts.',
        suited_for: 'Understanding step-by-step processes'
      },
      {
        name: 'Color-Coded Notes',
        description: 'Use different colors to organize and highlight important information.',
        suited_for: 'Better retention and quick review'
      },
    ],
    Auditory: [
      {
        name: 'Group Discussions',
        description: 'Talk through concepts with peers and teachers.',
        suited_for: 'Deepening understanding through dialogue'
      },
      {
        name: 'Podcast Learning',
        description: 'Listen to educational podcasts and audio courses.',
        suited_for: 'Learning while commuting or multitasking'
      },
      {
        name: 'Teaching Others',
        description: 'Explain concepts aloud to reinforce your understanding.',
        suited_for: 'Consolidating knowledge and identifying gaps'
      },
      {
        name: 'Audio Summaries',
        description: 'Create audio recordings of key points and listen to them.',
        suited_for: 'Reinforcing learning through listening'
      },
    ],
    Kinesthetic: [
      {
        name: 'Hands-On Projects',
        description: 'Create physical projects and practical demonstrations.',
        suited_for: 'Applying knowledge to real situations'
      },
      {
        name: 'Simulations',
        description: 'Use interactive simulations and virtual labs.',
        suited_for: 'Experiencing processes safely and repeatedly'
      },
      {
        name: 'Role-Playing',
        description: 'Act out scenarios to understand concepts deeply.',
        suited_for: 'Learning social and applied concepts'
      },
      {
        name: 'Practice Problems',
        description: 'Solve lots of practice problems with immediate feedback.',
        suited_for: 'Building skills and confidence'
      },
    ],
    'Reading/Writing': [
      {
        name: 'Note-Taking',
        description: 'Take comprehensive notes in your own words.',
        suited_for: 'Capturing and organizing information'
      },
      {
        name: 'Summary Writing',
        description: 'Write summaries of key concepts and topics.',
        suited_for: 'Reviewing and consolidating information'
      },
      {
        name: 'Reading Textbooks',
        description: 'Read and analyze textbooks carefully with annotations.',
        suited_for: 'Deep understanding of complex topics'
      },
      {
        name: 'Writing Essays',
        description: 'Write essays and reflections on topics to solidify understanding.',
        suited_for: 'Comprehensive analysis and critical thinking'
      },
    ],
  };

  return techniquesMap[profile.dominantStyle] || techniquesMap['Visual'];
};

const getRecommendedResources = (profile: LearningProfile) => {
  const resourceMap: Record<string, { type: 'videos' | 'books' | 'interactive' | 'practice'; examples: string[] }[]> = {
    Visual: [
      {
        type: 'videos',
        examples: ['YouTube channels (Khan Academy, TED-Ed)', 'Online video courses (Udemy, Coursera)']
      },
      {
        type: 'interactive',
        examples: ['Interactive diagrams', 'Simulation tools', 'Virtual whiteboarding apps']
      },
      {
        type: 'books',
        examples: ['Books with illustrations', 'Graphic novels', 'Infographic guides']
      },
    ],
    Auditory: [
      {
        type: 'videos',
        examples: ['Lecture videos', 'Audiobook platforms (Audible, Libby)']
      },
      {
        type: 'interactive',
        examples: ['Podcast platforms (Spotify, Apple Podcasts)', 'Discussion forums']
      },
      {
        type: 'books',
        examples: ['Audiobooks', 'Spoken word recordings']
      },
    ],
    Kinesthetic: [
      {
        type: 'interactive',
        examples: ['Virtual labs', 'Interactive games', 'Simulation software', 'AR/VR applications']
      },
      {
        type: 'practice',
        examples: ['Hands-on experiments', 'Project-based learning', 'Practical workshops']
      },
      {
        type: 'videos',
        examples: ['Tutorial videos (DIY, science experiments)', 'Demo videos']
      },
    ],
    'Reading/Writing': [
      {
        type: 'books',
        examples: ['Textbooks', 'Research papers', 'E-books', 'Online articles']
      },
      {
        type: 'interactive',
        examples: ['Online writing tools', 'Note-taking apps (Notion, OneNote)', 'Document editors']
      },
      {
        type: 'practice',
        examples: ['Writing assignments', 'Reading comprehension tests', 'Essay writing exercises']
      },
    ],
  };

  return resourceMap[profile.dominantStyle] || resourceMap['Visual'];
};

const getStudyTips = (profile: LearningProfile): string[] => {
  const tips: string[] = [];

  tips.push(`Your dominant learning style is ${profile.dominantStyle} - leverage this strength in your studies.`);

  if (profile.pace === 'Fast-Paced') {
    tips.push('Use quick review sessions and rapid practice to stay engaged.');
    tips.push('Break complex topics into small, manageable chunks.');
  } else if (profile.pace === 'Detailed') {
    tips.push('Allocate more time for in-depth study and thorough understanding.');
    tips.push('Take deep dives into topics rather than surface-level reviews.');
  } else {
    tips.push('Use the Pomodoro technique: 25-minute focus sessions with 5-minute breaks.');
    tips.push('Balance speed with comprehension in your study approach.');
  }

  if (profile.engagementStyle === 'Active Participant') {
    tips.push('Participate actively in study groups and class discussions.');
    tips.push('Ask questions and engage with the material to enhance learning.');
  } else if (profile.engagementStyle === 'Reflective Observer') {
    tips.push('Take time for quiet reflection and internal processing.');
    tips.push('Before asking questions, give yourself time to think deeply.');
  } else {
    tips.push('Balance active participation with reflective thinking.');
  }

  tips.push(profile.studyEnvironment);
  tips.push(profile.optimalStudyTime);

  tips.push('Review and revise regularly to keep information fresh in your memory.');
  tips.push('Combine multiple study techniques to reinforce learning from different angles.');

  if (profile.growthAreas.length > 0) {
    tips.push(`Work on improving: ${profile.growthAreas[0]} to become a more well-rounded learner.`);
  }

  return tips;
};

const generateWeeklySchedule = (profile: LearningProfile) => {
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  return days.map(day => ({
    day,
    sessions: generateDaySessions(profile, day),
  }));
};

const generateDaySessions = (profile: LearningProfile, day: string) => {
  const sessions = [];

  const baseSubjects = ['Mathematics', 'Language', 'Science', 'Social Studies', 'General Learning'];
  const techniques = getTechniquesByStyle(profile.dominantStyle);

  if (day === 'Saturday' || day === 'Sunday') {
    sessions.push({
      time: '09:00 - 10:30',
      subject: 'Subject Review',
      technique: 'Weekly Review and Consolidation',
      duration: 90,
    });
    sessions.push({
      time: '11:00 - 12:00',
      subject: 'Practice Problems',
      technique: 'Problem-Solving Practice',
      duration: 60,
    });
    sessions.push({
      time: '14:00 - 15:30',
      subject: 'Creative Projects',
      technique: 'Application and Projects',
      duration: 90,
    });
  } else {
    const morningTechnique = techniques[0] || 'Active Learning';
    const eveningTechnique = techniques[1] || 'Practice';

    sessions.push({
      time: '07:00 - 08:00',
      subject: baseSubjects[Math.floor(Math.random() * baseSubjects.length)],
      technique: morningTechnique,
      duration: 60,
    });

    sessions.push({
      time: '16:00 - 17:30',
      subject: baseSubjects[Math.floor(Math.random() * baseSubjects.length)],
      technique: eveningTechnique,
      duration: 90,
    });

    if (profile.pace !== 'Fast-Paced') {
      sessions.push({
        time: '19:30 - 20:30',
        subject: 'Revision',
        technique: 'Review Previous Topics',
        duration: 60,
      });
    }
  }

  return sessions;
};

const getTechniquesByStyle = (style: string): string[] => {
  const techniqueMap: Record<string, string[]> = {
    Visual: ['Visual Study (Diagrams, Mind Maps)', 'Color-Coded Notes', 'Video Learning'],
    Auditory: ['Group Discussion', 'Teaching Others', 'Podcast Learning'],
    Kinesthetic: ['Hands-On Practice', 'Simulations', 'Project Work'],
    'Reading/Writing': ['Reading & Annotation', 'Note-Taking', 'Essay Writing'],
  };

  return techniqueMap[style] || techniqueMap['Visual'];
};
