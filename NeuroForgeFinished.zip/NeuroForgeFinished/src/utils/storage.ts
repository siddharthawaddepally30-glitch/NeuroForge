export const LOCAL_STORAGE_KEYS = {
  ASSESSMENT_RESPONSES: 'learningStyle_responses',
  LEARNING_PROFILE: 'learningStyle_profile',
  USER_GOALS: 'learningStyle_goals',
  USER_INTERESTS: 'learningStyle_interests',
};

export const getFromStorage = <T>(key: string, defaultValue?: T): T | null => {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue || null;
  } catch {
    return defaultValue || null;
  }
};

export const saveToStorage = (key: string, value: any): void => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error('Failed to save to local storage:', error);
  }
};

export const removeFromStorage = (key: string): void => {
  try {
    localStorage.removeItem(key);
  } catch (error) {
    console.error('Failed to remove from local storage:', error);
  }
};

export const clearAllStorage = (): void => {
  try {
    Object.values(LOCAL_STORAGE_KEYS).forEach(key => {
      localStorage.removeItem(key);
    });
  } catch (error) {
    console.error('Failed to clear local storage:', error);
  }
};
